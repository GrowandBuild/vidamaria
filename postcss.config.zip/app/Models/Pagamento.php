<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pagamento extends Model
{
    use HasFactory;

    protected $table = 'pagamentos';

    protected $fillable = [
        'agendamento_id',
        'forma_pagamento_id',
        'valor',
        'taxa',
        'valor_liquido',
        'valor_profissional',
        'valor_empresa',
        'gorjeta',
    ];

    protected $casts = [
        'valor' => 'decimal:2',
        'taxa' => 'decimal:2',
        'valor_liquido' => 'decimal:2',
        'valor_profissional' => 'decimal:2',
        'valor_empresa' => 'decimal:2',
        'gorjeta' => 'decimal:2',
    ];

    // Relacionamentos
    public function agendamento()
    {
        return $this->belongsTo(Agendamento::class);
    }

    public function formaPagamento()
    {
        return $this->belongsTo(FormaPagamento::class);
    }

    // Calcular automaticamente os valores ao criar pagamento
    public static function calcularValores($valor, FormaPagamento $formaPagamento, Profissional $profissional, $gorjeta = 0)
    {
        // 1. Calcular taxa
        $taxa = $formaPagamento->calcularTaxa($valor);
        
        // 2. Valor líquido (após taxa)
        $valorLiquido = $valor - $taxa;
        
        // 3. Dividir entre profissional e empresa
        $percentualProfissional = $profissional->percentual_comissao;
        $valorProfissional = ($valorLiquido * $percentualProfissional) / 100;
        $valorEmpresa = $valorLiquido - $valorProfissional;

        return [
            'valor' => $valor,
            'taxa' => $taxa,
            'valor_liquido' => $valorLiquido,
            'valor_profissional' => $valorProfissional,
            'valor_empresa' => $valorEmpresa,
            'gorjeta' => $gorjeta,
        ];
    }
}

