# 💅 Esmalteria Vida Maria - Sistema de Gestão Premium

Sistema completo de agendamentos e gestão financeira desenvolvido em Laravel com PWA (Progressive Web App).

![Status](https://img.shields.io/badge/status-active-success.svg)
![Laravel](https://img.shields.io/badge/Laravel-9.x-red.svg)
![PHP](https://img.shields.io/badge/PHP-8.0+-blue.svg)
![PWA](https://img.shields.io/badge/PWA-Ready-purple.svg)

---

## ✨ Funcionalidades Principais

### 📅 **Módulo de Agendamentos**
- ✅ Agenda visual com cores por status
- ✅ Criar/editar/cancelar agendamentos
- ✅ Clientes cadastrados ou avulsos
- ✅ Sistema de 3 status: Agendado → Pré-Concluído → Confirmado
- ✅ Filtros por data e profissional
- ✅ Responsivo mobile-first

### 💰 **Módulo Financeiro**
- ✅ Dashboard financeiro em tempo real
- ✅ Divisão automática de receitas por percentual
- ✅ Múltiplas formas de pagamento
- ✅ Cálculo automático de taxas
- ✅ Gorjetas 100% para profissional
- ✅ Relatórios por dia/semana/mês/ano
- ✅ Gráfico de evolução mensal
- ✅ Ranking de clientes

### 👥 **Gestão de Usuários**
- ✅ 2 tipos: Proprietária e Profissional
- ✅ Controle de permissões por role
- ✅ Dashboard personalizado por perfil
- ✅ Sistema de pré-conclusão para profissionais

### 📊 **Cadastros**
- ✅ Profissionais (com % de comissão configurável)
- ✅ Clientes (com histórico completo)
- ✅ Serviços (editáveis, preço + duração)
- ✅ Formas de pagamento (com taxas)

### 📱 **PWA - Progressive Web App**
- ✅ Instalável como app nativo
- ✅ Funciona offline
- ✅ Ícone na tela inicial
- ✅ Splash screen personalizada
- ✅ Notificações push (preparado)
- ✅ Atalhos rápidos

---

## 🎨 Identidade Visual

- **Cores Principais:**
  - Azul Marinho: `#0A1647` (Elegância e Confiança)
  - Dourado: `#D4AF37` (Luxo e Premium)
  
- **Status por Cor:**
  - 🔵 Azul = Agendado
  - 🟠 Laranja = Pré-Concluído (aguardando)
  - 🟢 Verde = Confirmado (oficial)
  - ⚫ Cinza = Cancelado

---

## 🛠️ Tecnologias Utilizadas

- **Backend:** Laravel 9.x
- **Frontend:** Blade + Tailwind CSS 3.x
- **Autenticação:** Laravel Breeze
- **Database:** MySQL
- **PWA:** Service Workers + Manifest
- **Icons:** Heroicons (SVG)
- **Build:** Vite

---

## 📋 Requisitos

- PHP >= 8.0
- Composer
- Node.js >= 16.x
- MySQL >= 5.7
- Servidor web (Apache/Nginx)
- HTTPS (obrigatório para PWA)

---

## 🚀 Instalação Local

```bash
# 1. Clonar repositório
git clone [url-do-repo]
cd sistema-vida-maria

# 2. Instalar dependências PHP
composer install

# 3. Instalar dependências Node
npm install

# 4. Configurar ambiente
cp .env.example .env
php artisan key:generate

# 5. Configurar banco de dados no .env
# Editar DB_DATABASE, DB_USERNAME, DB_PASSWORD

# 6. Rodar migrations e seeders
php artisan migrate --seed

# 7. Criar usuário proprietária
php artisan db:seed --class=UserSeeder

# 8. Compilar assets
npm run build

# 9. Iniciar servidor
php artisan serve
```

**Acesse:** http://localhost:8000

**Login:** 
- Email: `admin@esmalteria.com`
- Senha: `admin123`

---

## 🌐 Deploy na Hostinger

Siga o guia completo em: [`DEPLOY_HOSTINGER.md`](DEPLOY_HOSTINGER.md)

**Resumo:**
1. Upload dos arquivos
2. Configurar `.env`
3. Criar banco MySQL
4. Rodar migrations
5. Configurar SSL/HTTPS
6. Ajustar permissões
7. Gerar ícones PNG
8. Testar PWA

---

## 📱 Transformar em PWA

### **Gerar Ícones:**

Veja instruções em: [`GERAR_ICONES.md`](GERAR_ICONES.md)

### **Testar PWA:**

```bash
# 1. Servir via HTTPS (obrigatório)
# Local: usar ngrok ou valet

# 2. Abrir Chrome DevTools
# Application → Manifest → Verificar

# 3. Testar instalação
# Chrome → Menu → Instalar app
```

---

## 👤 Usuários Padrão

### **Proprietária**
- Email: `admin@esmalteria.com`
- Senha: `admin123`
- Acesso: Total

### **Profissional** (criar via sistema)
- Acesso: Limitado (agenda própria + ganhos)

---

## 📊 Estrutura do Banco

```
users (autenticação)
├── profissionais (dados + comissão)
├── clientes (cadastro opcional)
├── servicos (editável)
├── formas_pagamento (Dinheiro, PIX, Cartões)
├── agendamentos (status workflow)
└── pagamentos (cálculos automáticos)
```

---

## 🔐 Permissões por Role

| Recurso | Profissional | Proprietária |
|---------|--------------|--------------|
| Ver própria agenda | ✅ | ✅ |
| Ver todas agendas | ❌ | ✅ |
| Criar agendamento | ✅ | ✅ |
| Editar agendamento | ❌ | ✅ |
| Pré-concluir (fechar) | ✅ | ✅ |
| Confirmar conclusão | ❌ | ✅ |
| Ver próprios ganhos | ✅ | ✅ |
| Ver financeiro completo | ❌ | ✅ |
| Cadastrar cliente | ✅ | ✅ |
| Editar cliente | ❌ | ✅ |
| Cadastrar profissional | ❌ | ✅ |
| Cadastrar serviço | ❌ | ✅ |

---

## 💡 Fluxo de Trabalho

### **Profissional:**
1. Acessa agenda (bottom nav)
2. Vê seus atendimentos do dia
3. Atende cliente
4. Clica "Concluir" → Faz pagamento
5. Status: **🟠 Pré-Concluído**
6. Vê ganhos como "Aguardando" em laranja
7. Acessa **Financeiro** (ícone $) → Vê totais do dia/semana/mês/ano

### **Proprietária:**
1. Dashboard mostra **🔔 Badge laranja** com pendentes
2. Vai na Agenda
3. Vê cards laranjas (pré-concluídos)
4. Revisa valores
5. Clica **"✓ Confirmar"**
6. Status: **🟢 Confirmado**
7. Valores entram oficialmente no caixa
8. Acessa **Financeiro** → Relatórios completos

---

## 📱 Navegação Mobile

**Bottom Navigation:**
- 🏠 Início (Dashboard)
- 📅 Agenda
- 💰 Financeiro
- ☰ Menu (mais opções)

**Menu Hamburguer:**
- Profissionais (só proprietária)
- Clientes (todos)
- Serviços (só proprietária)
- Perfil
- Sair

---

## 🎨 Customização

### **Cores:**
Editar em: `tailwind.config.js`

```javascript
colors: {
  'vm-navy': { ... },
  'vm-gold': { ... }
}
```

### **Serviços:**
Editar em: `database/seeders/ServicosSeeder.php`

### **Formas de Pagamento:**
Editar em: `database/seeders/FormasPagamentoSeeder.php`

---

## 🐛 Troubleshooting

### **Erro 500**
```bash
chmod -R 775 storage bootstrap/cache
php artisan config:clear
```

### **Assets não carregam**
```bash
npm run build
php artisan view:clear
```

### **PWA não instala**
- Verificar HTTPS ativo
- Manifest em `/manifest.json`
- Service Worker em `/service-worker.js`
- Ícones PNG criados

### **Migrations com erro**
```bash
php artisan migrate:fresh --seed
```

---

## 📚 Documentação Adicional

- [Identidade Visual](IDENTIDADE_VISUAL.md)
- [Deploy Hostinger](DEPLOY_HOSTINGER.md)
- [Gerar Ícones](GERAR_ICONES.md)

---

## 🔄 Atualizações Futuras

- [ ] Notificações WhatsApp
- [ ] Notificações Email
- [ ] Exportar relatórios PDF
- [ ] Gráficos interativos
- [ ] Controle de estoque
- [ ] Integração com calendário Google
- [ ] Sistema de avaliações
- [ ] Fotos antes/depois

---

## 📄 Licença

Desenvolvido exclusivamente para **Esmalteria Vida Maria**.

---

## 👨‍💻 Desenvolvimento

Desenvolvido com ❤️ usando Laravel + PWA

**Versão:** 1.0.0  
**Data:** Outubro 2025

---

## 📞 Suporte

Para dúvidas ou problemas:
- Verificar documentação
- Checar logs: `storage/logs/laravel.log`
- Revisar guias de deploy

---

**Sistema Completo • Mobile-First • PWA Ready • Padrão Ouro** ✨
