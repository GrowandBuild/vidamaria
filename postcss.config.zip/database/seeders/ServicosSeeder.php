<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Servico;

class ServicosSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $servicos = [
            ['nome' => 'Manicure', 'preco' => 30.00, 'duracao_minutos' => 45],
            ['nome' => 'Pedicure', 'preco' => 35.00, 'duracao_minutos' => 60],
            ['nome' => 'Esmaltação em Gel', 'preco' => 50.00, 'duracao_minutos' => 60],
            ['nome' => 'Spa dos Pés', 'preco' => 60.00, 'duracao_minutos' => 90],
            ['nome' => 'Unhas Decoradas', 'preco' => 70.00, 'duracao_minutos' => 90],
            ['nome' => 'Manicure + Pedicure', 'preco' => 55.00, 'duracao_minutos' => 120],
        ];

        foreach ($servicos as $servico) {
            Servico::create($servico);
        }
    }
}

