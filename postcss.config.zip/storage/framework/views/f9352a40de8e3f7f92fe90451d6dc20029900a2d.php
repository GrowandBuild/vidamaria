<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="font-sans text-gray-900 antialiased gradient-navy-gold">
        <div class="min-h-screen flex flex-col justify-center items-center px-4 py-6">
            <!-- Logo -->
            <div class="mb-6 sm:mb-8 animate-fade-in">
                <a href="/" class="transition-transform duration-300 hover:scale-105 block">
                    <img src="<?php echo e(asset('logo.svg')); ?>" alt="Esmalteria Vida Maria" class="h-20 sm:h-28 w-auto mx-auto">
                </a>
            </div>

            <!-- Card de Login -->
            <div class="w-full max-w-md">
                <div class="bg-white shadow-2xl overflow-hidden rounded-2xl border-t-4 border-vm-gold">
                    <div class="px-6 sm:px-8 py-6 sm:py-8">
                        <?php echo e($slot); ?>

                    </div>
                </div>
            </div>
            
            <!-- Rodapé -->
            <p class="mt-6 text-vm-gold-200 text-xs sm:text-sm text-center px-4">
                © <?php echo e(date('Y')); ?> Esmalteria Vida Maria<br class="sm:hidden">
                <span class="hidden sm:inline"> - </span>Elegância e Sofisticação
            </p>
        </div>
    </body>
</html>
<?php /**PATH C:\Users\Alexandre\Desktop\sistema para esmalteria\resources\views/layouts/guest.blade.php ENDPATH**/ ?>