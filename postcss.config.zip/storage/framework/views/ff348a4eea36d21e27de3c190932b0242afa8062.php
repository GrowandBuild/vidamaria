

<?php $__env->startSection('title', 'Meus Ganhos'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
    <!-- Filtro de Período -->
    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-4 sm:mb-6 mx-4 sm:mx-0">
        <div class="p-4 sm:p-6">
            <form method="GET" action="<?php echo e(route('dashboard')); ?>" class="flex flex-col sm:flex-row gap-3 sm:gap-4">
                <div class="flex-1">
                    <label class="block text-xs sm:text-sm font-medium text-gray-700 mb-1">Data Início</label>
                    <input type="date" name="data_inicio" value="<?php echo e($dataInicio); ?>" 
                           class="block w-full rounded-md border-gray-300 shadow-sm focus:border-vm-gold focus:ring-vm-gold text-sm">
                </div>
                <div class="flex-1">
                    <label class="block text-xs sm:text-sm font-medium text-gray-700 mb-1">Data Fim</label>
                    <input type="date" name="data_fim" value="<?php echo e($dataFim); ?>" 
                           class="block w-full rounded-md border-gray-300 shadow-sm focus:border-vm-gold focus:ring-vm-gold text-sm">
                </div>
                <button type="submit" class="btn-primary w-full sm:w-auto sm:mt-5">
                    Filtrar Período
                </button>
            </form>
        </div>
    </div>

    <!-- Cards Resumo -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-4 mb-4 sm:mb-6 px-4 sm:px-0">
        <!-- Total Confirmado -->
        <div class="bg-gradient-to-br from-green-500 to-green-600 overflow-hidden shadow-lg rounded-lg">
            <div class="p-4 sm:p-6 text-white">
                <div class="text-xs sm:text-sm font-semibold uppercase">✓ Confirmado</div>
                <div class="mt-2 text-xl sm:text-3xl font-bold">R$ <?php echo e(number_format($totalGanhos, 2, ',', '.')); ?></div>
                <div class="mt-1 text-xs opacity-80">Oficial</div>
            </div>
        </div>

        <!-- Total Pré-Concluído (Aguardando) -->
        <div class="bg-gradient-to-br from-orange-400 to-orange-500 overflow-hidden shadow-lg rounded-lg">
            <div class="p-4 sm:p-6 text-white">
                <div class="text-xs sm:text-sm font-semibold uppercase">⏳ Aguardando</div>
                <div class="mt-2 text-xl sm:text-3xl font-bold">R$ <?php echo e(number_format($totalGanhosPreConcluido, 2, ',', '.')); ?></div>
                <div class="mt-1 text-xs opacity-80">A confirmar</div>
            </div>
        </div>

        <!-- Comissões -->
        <div class="bg-gradient-to-br from-blue-500 to-blue-600 overflow-hidden shadow-lg rounded-lg">
            <div class="p-4 sm:p-6 text-white">
                <div class="text-xs sm:text-sm font-semibold uppercase">Comissões</div>
                <div class="mt-2 text-xl sm:text-3xl font-bold">R$ <?php echo e(number_format($totalComissao, 2, ',', '.')); ?></div>
                <div class="mt-1 text-xs opacity-80"><?php echo e($profissional->percentual_comissao); ?>%</div>
            </div>
        </div>

        <!-- Gorjetas -->
        <div class="bg-gradient-to-br from-purple-500 to-purple-600 overflow-hidden shadow-lg rounded-lg">
            <div class="p-4 sm:p-6 text-white">
                <div class="text-xs sm:text-sm font-semibold uppercase">Gorjetas</div>
                <div class="mt-2 text-xl sm:text-3xl font-bold">R$ <?php echo e(number_format($totalGorjetas, 2, ',', '.')); ?></div>
                <div class="mt-1 text-xs opacity-80">100%</div>
            </div>
        </div>

        <!-- Total de Atendimentos -->
        <div class="bg-gradient-to-br from-indigo-500 to-indigo-600 overflow-hidden shadow-lg rounded-lg">
            <div class="p-4 sm:p-6 text-white">
                <div class="text-xs sm:text-sm font-semibold uppercase">Atendimentos</div>
                <div class="mt-2 text-xl sm:text-3xl font-bold"><?php echo e($totalAtendimentos); ?></div>
                <div class="mt-1 text-xs opacity-80">Confirmados</div>
            </div>
        </div>
    </div>

    <!-- Minha Agenda de Hoje -->
    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg px-4 sm:px-0">
        <div class="p-3 sm:p-6">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-base sm:text-lg font-semibold">Minha Agenda de Hoje</h3>
                <a href="<?php echo e(route('agendamentos.agenda')); ?>" class="text-vm-gold hover:text-vm-gold-600 text-xs sm:text-sm font-medium">
                    Ver agenda completa →
                </a>
            </div>
            
            <div class="space-y-3">
                <?php $__empty_1 = true; $__currentLoopData = $agendamentosHoje; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agendamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="rounded-lg p-3 sm:p-4 
                        <?php if($agendamento->status == 'concluido'): ?> 
                            bg-gradient-to-r from-green-500 to-green-600 text-white
                        <?php elseif($agendamento->status == 'pre_concluido'): ?> 
                            bg-gradient-to-r from-orange-400 to-orange-500 text-white
                        <?php elseif($agendamento->status == 'agendado'): ?> 
                            bg-gradient-to-r from-blue-500 to-blue-600 text-white
                        <?php else: ?> 
                            bg-gradient-to-r from-gray-400 to-gray-500 text-white
                        <?php endif; ?>
                        shadow-md hover:shadow-lg transition-all">
                        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                            <div class="flex items-center gap-3 flex-1">
                                <div class="text-xl sm:text-2xl font-bold">
                                    <?php echo e($agendamento->data_hora->format('H:i')); ?>

                                </div>
                                <div class="flex-1">
                                    <div class="font-semibold text-sm sm:text-base"><?php echo e($agendamento->nome_cliente); ?></div>
                                    <?php if($agendamento->servico): ?>
                                        <div class="text-xs sm:text-sm opacity-90">
                                            <?php echo e($agendamento->servico->nome); ?> - R$ <?php echo e(number_format($agendamento->servico->preco, 2, ',', '.')); ?>

                                        </div>
                                    <?php else: ?>
                                        <div class="text-xs sm:text-sm opacity-90">Serviço não especificado</div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="flex items-center gap-2">
                                <span class="px-3 py-1 text-xs rounded-full font-bold bg-white/20 backdrop-blur-sm border border-white/30">
                                    <?php if($agendamento->status == 'concluido'): ?> ✓ Confirmado
                                    <?php elseif($agendamento->status == 'pre_concluido'): ?> ⏳ Aguardando
                                    <?php elseif($agendamento->status == 'agendado'): ?> ⏰ Agendado
                                    <?php else: ?> ✕ Cancelado
                                    <?php endif; ?>
                                </span>
                                <?php if($agendamento->status == 'agendado'): ?>
                                    <a href="<?php echo e(route('agendamentos.concluir', $agendamento)); ?>" 
                                       class="px-2 sm:px-3 py-1 bg-white text-green-700 text-xs font-semibold rounded hover:bg-green-50 whitespace-nowrap shadow-md">
                                        ✓ Concluir
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="text-center py-8 text-gray-500">
                        Nenhum agendamento para hoje
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alexandre\Desktop\sistema para esmalteria\resources\views/dashboard/profissional.blade.php ENDPATH**/ ?>