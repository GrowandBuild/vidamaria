<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ProfissionalController;
use App\Http\Controllers\ClienteController;
use App\Http\Controllers\ServicoController;
use App\Http\Controllers\AgendamentoController;
use App\Http\Controllers\FinanceiroController;
use App\Http\Controllers\FormaPagamentoController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return redirect()->route('login');
});

Route::middleware('auth')->group(function () {
    // Dashboard
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    
    // Financeiro
    Route::get('/financeiro', [FinanceiroController::class, 'index'])->name('financeiro');

    // Perfil
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    // Agendamentos (todos podem acessar)
    Route::get('/agenda', [AgendamentoController::class, 'agenda'])->name('agendamentos.agenda');
    Route::resource('agendamentos', AgendamentoController::class);
    Route::get('/agendamentos/{agendamento}/concluir', [AgendamentoController::class, 'concluir'])->name('agendamentos.concluir');
    Route::post('/agendamentos/{agendamento}/finalizar', [AgendamentoController::class, 'finalizarPagamento'])->name('agendamentos.finalizar');
    Route::post('/agendamentos/{agendamento}/confirmar', [AgendamentoController::class, 'confirmarConclusao'])->name('agendamentos.confirmar')->middleware('can:isProprietaria');
    Route::delete('/agendamentos/{agendamento}/deletar', [AgendamentoController::class, 'deletarCompletamente'])->name('agendamentos.deletar')->middleware('can:isProprietaria');

    // Clientes (todos podem ver e criar - para facilitar cadastro rápido)
    Route::resource('clientes', ClienteController::class)->only(['index', 'create', 'store', 'show']);
    
    // Rotas exclusivas para Proprietária
    Route::middleware('can:isProprietaria')->group(function () {
        Route::resource('profissionais', ProfissionalController::class);
        Route::post('/profissionais/{profissional}/toggle', [ProfissionalController::class, 'toggleStatus'])->name('profissionais.toggle');
        
        Route::resource('clientes', ClienteController::class)->only(['edit', 'update', 'destroy']);
        
        Route::resource('servicos', ServicoController::class);
        Route::post('/servicos/{servico}/toggle', [ServicoController::class, 'toggleStatus'])->name('servicos.toggle');
        
        Route::get('/formas-pagamento', [FormaPagamentoController::class, 'index'])->name('formas-pagamento.index');
        Route::get('/formas-pagamento/{formaPagamento}/edit', [FormaPagamentoController::class, 'edit'])->name('formas-pagamento.edit');
        Route::put('/formas-pagamento/{formaPagamento}', [FormaPagamentoController::class, 'update'])->name('formas-pagamento.update');
        Route::post('/formas-pagamento/{formaPagamento}/toggle', [FormaPagamentoController::class, 'toggleStatus'])->name('formas-pagamento.toggle');
    });
});

require __DIR__.'/auth.php';
