

<?php $__env->startSection('title', 'Dashboard Financeiro'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
    <!-- Filtro de Período -->
    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-4 sm:mb-6 mx-4 sm:mx-0">
        <div class="p-4 sm:p-6">
            <form method="GET" action="<?php echo e(route('dashboard')); ?>" class="flex flex-col sm:flex-row gap-3 sm:gap-4">
                <div class="flex-1">
                    <label class="block text-xs sm:text-sm font-medium text-gray-700 mb-1">Data Início</label>
                    <input type="date" name="data_inicio" value="<?php echo e($dataInicio); ?>" 
                           class="block w-full rounded-md border-gray-300 shadow-sm focus:border-vm-gold focus:ring-vm-gold text-sm">
                </div>
                <div class="flex-1">
                    <label class="block text-xs sm:text-sm font-medium text-gray-700 mb-1">Data Fim</label>
                    <input type="date" name="data_fim" value="<?php echo e($dataFim); ?>" 
                           class="block w-full rounded-md border-gray-300 shadow-sm focus:border-vm-gold focus:ring-vm-gold text-sm">
                </div>
                <button type="submit" class="btn-primary w-full sm:w-auto sm:mt-5">
                    Filtrar Período
                </button>
            </form>
        </div>
    </div>

    <!-- Cards Resumo -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4 sm:gap-6 mb-4 sm:mb-6 px-4 sm:px-0">
        <!-- Total da Empresa (Confirmado) -->
        <div class="bg-gradient-to-br from-green-500 to-green-600 overflow-hidden shadow-lg rounded-lg">
            <div class="p-4 sm:p-6 text-white">
                <div class="text-xs sm:text-sm font-semibold uppercase">Confirmado</div>
                <div class="mt-2 text-2xl sm:text-4xl font-bold">R$ <?php echo e(number_format($totalEmpresa, 2, ',', '.')); ?></div>
                <div class="mt-1 sm:mt-2 text-xs opacity-80">Parte da empresa</div>
            </div>
        </div>

        <!-- Pendente de Confirmação -->
        <div class="bg-gradient-to-br from-orange-400 to-orange-500 overflow-hidden shadow-lg rounded-lg">
            <div class="p-4 sm:p-6 text-white">
                <div class="text-xs sm:text-sm font-semibold uppercase flex items-center gap-1">
                    Aguardando
                    <?php if($agendamentosPendentes > 0): ?>
                        <span class="bg-white text-orange-600 rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold"><?php echo e($agendamentosPendentes); ?></span>
                    <?php endif; ?>
                </div>
                <div class="mt-2 text-2xl sm:text-4xl font-bold">R$ <?php echo e(number_format($totalPreConcluido, 2, ',', '.')); ?></div>
                <div class="mt-1 sm:mt-2 text-xs opacity-80">A confirmar</div>
            </div>
        </div>

        <!-- Total das Profissionais -->
        <div class="bg-gradient-to-br from-blue-500 to-blue-600 overflow-hidden shadow-lg rounded-lg">
            <div class="p-4 sm:p-6 text-white">
                <div class="text-xs sm:text-sm font-semibold uppercase">Profissionais</div>
                <div class="mt-2 text-2xl sm:text-4xl font-bold">R$ <?php echo e(number_format($profissionais->sum('total'), 2, ',', '.')); ?></div>
                <div class="mt-1 sm:mt-2 text-xs opacity-80">Comissões + Gorjetas</div>
            </div>
        </div>

        <!-- Total Geral -->
        <div class="bg-gradient-to-br from-purple-500 to-purple-600 overflow-hidden shadow-lg rounded-lg">
            <div class="p-4 sm:p-6 text-white">
                <div class="text-xs sm:text-sm font-semibold uppercase">Faturamento</div>
                <div class="mt-2 text-2xl sm:text-4xl font-bold">R$ <?php echo e(number_format($totalGeral, 2, ',', '.')); ?></div>
                <div class="mt-1 sm:mt-2 text-xs opacity-80">Total confirmado</div>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <!-- Desempenho por Profissional -->
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
            <div class="p-6">
                <h3 class="text-lg font-semibold mb-4">Desempenho por Profissional</h3>
                <div class="space-y-3">
                    <?php $__empty_1 = true; $__currentLoopData = $profissionais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prof): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="border-l-4 border-indigo-500 pl-4 py-2">
                            <div class="flex justify-between items-start">
                                <div>
                                    <div class="font-semibold text-gray-800"><?php echo e($prof['nome']); ?></div>
                                    <div class="text-xs text-gray-500">Comissão: <?php echo e($prof['percentual']); ?>%</div>
                                </div>
                                <div class="text-right">
                                    <div class="font-bold text-gray-800">R$ <?php echo e(number_format($prof['total'], 2, ',', '.')); ?></div>
                                    <div class="text-xs text-gray-500">
                                        Comissão: R$ <?php echo e(number_format($prof['total_comissao'], 2, ',', '.')); ?><br>
                                        Gorjetas: R$ <?php echo e(number_format($prof['total_gorjetas'], 2, ',', '.')); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-gray-500 text-center py-4">Nenhum atendimento no período</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Ranking de Clientes -->
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
            <div class="p-6">
                <h3 class="text-lg font-semibold mb-4">Top 10 Clientes (Lucro Gerado)</h3>
                <div class="space-y-2">
                    <?php $__empty_1 = true; $__currentLoopData = $rankingClientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="flex items-center gap-3 p-2 hover:bg-gray-50 rounded">
                            <div class="flex-shrink-0 w-8 h-8 bg-gradient-to-br from-yellow-400 to-orange-500 text-white rounded-full flex items-center justify-center font-bold text-sm">
                                <?php echo e($index + 1); ?>

                            </div>
                            <div class="flex-1">
                                <div class="font-medium text-gray-800"><?php echo e($cliente['nome']); ?></div>
                                <div class="text-xs text-gray-500"><?php echo e($cliente['total_atendimentos']); ?> atendimentos</div>
                            </div>
                            <div class="text-right">
                                <div class="font-semibold text-green-600">R$ <?php echo e(number_format($cliente['lucro_gerado'], 2, ',', '.')); ?></div>
                                <div class="text-xs text-gray-500">Total: R$ <?php echo e(number_format($cliente['total_gasto'], 2, ',', '.')); ?></div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-gray-500 text-center py-4">Nenhum cliente cadastrado ainda</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Agendamentos de Hoje -->
    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg px-4 sm:px-0">
        <div class="p-3 sm:p-6">
            <h3 class="text-base sm:text-lg font-semibold mb-4">Agendamentos de Hoje</h3>
            <div class="space-y-3">
                <?php $__empty_1 = true; $__currentLoopData = $agendamentosHoje; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agendamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="rounded-lg p-3 sm:p-4 
                        <?php if($agendamento->status == 'concluido'): ?> 
                            bg-gradient-to-r from-green-500 to-green-600 text-white
                        <?php elseif($agendamento->status == 'pre_concluido'): ?> 
                            bg-gradient-to-r from-orange-400 to-orange-500 text-white
                        <?php elseif($agendamento->status == 'agendado'): ?> 
                            bg-gradient-to-r from-blue-500 to-blue-600 text-white
                        <?php else: ?> 
                            bg-gradient-to-r from-gray-400 to-gray-500 text-white
                        <?php endif; ?>
                        shadow-md hover:shadow-lg transition-all">
                        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                            <div class="flex items-center gap-3 flex-1">
                                <div class="text-xl sm:text-2xl font-bold">
                                    <?php echo e($agendamento->data_hora->format('H:i')); ?>

                                </div>
                                <div>
                                    <div class="font-semibold text-sm sm:text-base"><?php echo e($agendamento->nome_cliente); ?></div>
                                    <?php if($agendamento->servico): ?>
                                        <div class="text-xs sm:text-sm opacity-90"><?php echo e($agendamento->servico->nome); ?></div>
                                    <?php else: ?>
                                        <div class="text-xs sm:text-sm opacity-70">Serviço não especificado</div>
                                    <?php endif; ?>
                                    <div class="text-xs opacity-80"><?php echo e($agendamento->profissional->nome); ?></div>
                                </div>
                            </div>
                            <div class="flex items-center gap-2">
                                <span class="px-3 py-1 text-xs rounded-full font-bold bg-white/20 backdrop-blur-sm border border-white/30">
                                    <?php if($agendamento->status == 'concluido'): ?> ✓ Confirmado
                                    <?php elseif($agendamento->status == 'pre_concluido'): ?> ⏳ Pré-Concluído
                                    <?php elseif($agendamento->status == 'agendado'): ?> ⏰ Agendado
                                    <?php else: ?> ✕ Cancelado
                                    <?php endif; ?>
                                </span>
                                <?php if($agendamento->status == 'pre_concluido'): ?>
                                    <a href="<?php echo e(route('agendamentos.agenda')); ?>" 
                                       class="px-2 sm:px-3 py-1 bg-white text-green-700 text-xs font-semibold rounded hover:bg-green-50 whitespace-nowrap shadow-md">
                                        Ver Detalhes
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="text-center py-8 text-gray-500">
                        Nenhum agendamento para hoje
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alexandre\Desktop\sistema para esmalteria\resources\views/dashboard/proprietaria.blade.php ENDPATH**/ ?>