

<?php $__env->startSection('title', 'Concluir Atendimento'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto sm:px-6 lg:px-8">
    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
        <div class="p-6">
            <h2 class="text-2xl font-bold mb-6">Finalizar Pagamento</h2>

            <!-- Resumo do Atendimento -->
            <div class="bg-gray-50 p-4 rounded-lg mb-6">
                <h3 class="font-semibold mb-2">Detalhes do Atendimento</h3>
                <div class="grid grid-cols-2 gap-4 text-sm">
                    <div>
                        <span class="text-gray-600">Cliente:</span>
                        <span class="font-medium ml-2"><?php echo e($agendamento->nome_cliente); ?></span>
                    </div>
                    <div>
                        <span class="text-gray-600">Profissional:</span>
                        <span class="font-medium ml-2"><?php echo e($agendamento->profissional->nome); ?></span>
                    </div>
                    <div>
                        <span class="text-gray-600">Serviço:</span>
                        <span class="font-medium ml-2"><?php echo e($agendamento->servico->nome); ?></span>
                    </div>
                    <div>
                        <span class="text-gray-600">Valor do Serviço:</span>
                        <span class="font-medium ml-2 text-lg text-green-600">R$ <?php echo e(number_format($agendamento->servico->preco, 2, ',', '.')); ?></span>
                    </div>
                    <div>
                        <span class="text-gray-600">Comissão Profissional:</span>
                        <span class="font-medium ml-2"><?php echo e($agendamento->profissional->percentual_comissao); ?>%</span>
                    </div>
                </div>
            </div>

            <form method="POST" action="<?php echo e(route('agendamentos.finalizar', $agendamento)); ?>" id="pagamentoForm">
                <?php echo csrf_field(); ?>

                <div class="space-y-6">
                    <h3 class="text-lg font-semibold">Formas de Pagamento</h3>
                    
                    <div id="pagamentos-container">
                        <div class="pagamento-item border p-4 rounded-lg mb-4 bg-white">
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700">Forma de Pagamento</label>
                                    <select name="pagamentos[0][forma_pagamento_id]" required 
                                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 forma-pagamento-select"
                                            data-index="0">
                                        <option value="">Selecione...</option>
                                        <?php $__currentLoopData = $formasPagamento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $forma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($forma->id); ?>" data-taxa="<?php echo e($forma->taxa_percentual); ?>">
                                                <?php echo e($forma->nome); ?> 
                                                <?php if($forma->taxa_percentual > 0): ?>
                                                    (Taxa: <?php echo e($forma->taxa_percentual); ?>%)
                                                <?php endif; ?>
                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div>
                                    <label class="block text-sm font-medium text-gray-700">Valor</label>
                                    <input type="number" name="pagamentos[0][valor]" step="0.01" min="0" required
                                           class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 valor-input"
                                           data-index="0">
                                </div>

                                <div>
                                    <label class="block text-sm font-medium text-gray-700">Gorjeta</label>
                                    <input type="number" name="pagamentos[0][gorjeta]" step="0.01" min="0" value="0"
                                           class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                </div>
                            </div>
                            
                            <div class="mt-2 text-sm text-gray-600" id="calc-0">
                                <div class="grid grid-cols-3 gap-2 mt-2 p-2 bg-gray-50 rounded">
                                    <div>Taxa: <span class="font-semibold taxa-valor">R$ 0,00</span></div>
                                    <div>Profissional: <span class="font-semibold prof-valor">R$ 0,00</span></div>
                                    <div>Empresa: <span class="font-semibold emp-valor">R$ 0,00</span></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <button type="button" id="addPagamento" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm">
                        + Adicionar Forma de Pagamento
                    </button>

                    <!-- Resumo Total -->
                    <div class="bg-indigo-50 p-4 rounded-lg">
                        <h3 class="font-semibold mb-3">Resumo do Pagamento</h3>
                        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                            <div>
                                <div class="text-gray-600">Total Pago</div>
                                <div class="text-2xl font-bold text-gray-800" id="total-pago">R$ 0,00</div>
                            </div>
                            <div>
                                <div class="text-gray-600">Total Taxas</div>
                                <div class="text-xl font-semibold text-red-600" id="total-taxas">R$ 0,00</div>
                            </div>
                            <div>
                                <div class="text-gray-600">Profissional</div>
                                <div class="text-xl font-semibold text-blue-600" id="total-profissional">R$ 0,00</div>
                            </div>
                            <div>
                                <div class="text-gray-600">Empresa</div>
                                <div class="text-xl font-semibold text-green-600" id="total-empresa">R$ 0,00</div>
                            </div>
                        </div>
                    </div>

                    <!-- Botões -->
                    <div class="flex gap-3">
                        <button type="submit" class="px-6 py-3 bg-green-600 text-white rounded-md hover:bg-green-700 font-semibold">
                            Finalizar Atendimento
                        </button>
                        <a href="<?php echo e(route('agendamentos.agenda')); ?>" class="px-6 py-3 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400">
                            Cancelar
                        </a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    let pagamentoIndex = 1;
    const percentualComissao = <?php echo e($agendamento->profissional->percentual_comissao); ?>;

    function calcularValores(index) {
        const select = document.querySelector(`select[data-index="${index}"]`);
        const valorInput = document.querySelector(`input[name="pagamentos[${index}][valor]"]`);
        
        if (!select || !valorInput) return;
        
        const selectedOption = select.options[select.selectedIndex];
        const taxa = parseFloat(selectedOption.dataset.taxa || 0);
        const valor = parseFloat(valorInput.value || 0);
        
        const taxaValor = (valor * taxa) / 100;
        const valorLiquido = valor - taxaValor;
        const valorProf = (valorLiquido * percentualComissao) / 100;
        const valorEmp = valorLiquido - valorProf;
        
        const calcDiv = document.getElementById(`calc-${index}`);
        if (calcDiv) {
            calcDiv.querySelector('.taxa-valor').textContent = `R$ ${taxaValor.toFixed(2).replace('.', ',')}`;
            calcDiv.querySelector('.prof-valor').textContent = `R$ ${valorProf.toFixed(2).replace('.', ',')}`;
            calcDiv.querySelector('.emp-valor').textContent = `R$ ${valorEmp.toFixed(2).replace('.', ',')}`;
        }
        
        calcularTotais();
    }

    function calcularTotais() {
        let totalPago = 0;
        let totalTaxas = 0;
        let totalProf = 0;
        let totalEmp = 0;
        
        document.querySelectorAll('.valor-input').forEach((input, idx) => {
            const select = document.querySelector(`select[data-index="${input.dataset.index}"]`);
            if (!select) return;
            
            const selectedOption = select.options[select.selectedIndex];
            const taxa = parseFloat(selectedOption.dataset.taxa || 0);
            const valor = parseFloat(input.value || 0);
            const gorjeta = parseFloat(document.querySelector(`input[name="pagamentos[${input.dataset.index}][gorjeta]"]`).value || 0);
            
            const taxaValor = (valor * taxa) / 100;
            const valorLiquido = valor - taxaValor;
            const valorProf = (valorLiquido * percentualComissao) / 100;
            const valorEmp = valorLiquido - valorProf;
            
            totalPago += valor;
            totalTaxas += taxaValor;
            totalProf += valorProf + gorjeta;
            totalEmp += valorEmp;
        });
        
        document.getElementById('total-pago').textContent = `R$ ${totalPago.toFixed(2).replace('.', ',')}`;
        document.getElementById('total-taxas').textContent = `R$ ${totalTaxas.toFixed(2).replace('.', ',')}`;
        document.getElementById('total-profissional').textContent = `R$ ${totalProf.toFixed(2).replace('.', ',')}`;
        document.getElementById('total-empresa').textContent = `R$ ${totalEmp.toFixed(2).replace('.', ',')}`;
    }

    document.getElementById('addPagamento').addEventListener('click', function() {
        const container = document.getElementById('pagamentos-container');
        const newItem = document.querySelector('.pagamento-item').cloneNode(true);
        
        newItem.querySelectorAll('input, select').forEach(el => {
            const name = el.getAttribute('name');
            if (name) {
                el.setAttribute('name', name.replace(/\[\d+\]/, `[${pagamentoIndex}]`));
            }
            if (el.dataset.index !== undefined) {
                el.dataset.index = pagamentoIndex;
            }
            if (el.tagName === 'INPUT') {
                el.value = el.type === 'number' ? '0' : '';
            }
        });
        
        newItem.querySelector('[id^="calc-"]').id = `calc-${pagamentoIndex}`;
        
        const removeBtn = document.createElement('button');
        removeBtn.type = 'button';
        removeBtn.className = 'mt-2 px-3 py-1 bg-red-600 text-white rounded text-sm hover:bg-red-700';
        removeBtn.textContent = 'Remover';
        removeBtn.onclick = function() {
            newItem.remove();
            calcularTotais();
        };
        newItem.appendChild(removeBtn);
        
        container.appendChild(newItem);
        pagamentoIndex++;
        
        attachEventListeners(newItem);
    });

    function attachEventListeners(element) {
        element.querySelectorAll('.forma-pagamento-select, .valor-input').forEach(el => {
            el.addEventListener('change', function() {
                calcularValores(this.dataset.index);
            });
            el.addEventListener('input', function() {
                calcularValores(this.dataset.index);
            });
        });
    }

    attachEventListeners(document);
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alexandre\Desktop\sistema para esmalteria\resources\views/agendamentos/concluir.blade.php ENDPATH**/ ?>