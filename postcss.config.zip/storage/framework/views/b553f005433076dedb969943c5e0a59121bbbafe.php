

<?php $__env->startSection('title', 'Agenda'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
    <!-- Header com Filtros -->
    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-4 sm:mb-6">
        <div class="p-4 sm:p-6">
            <div class="flex flex-col gap-4">
                <div class="flex-1">
                    <h2 class="text-xl sm:text-2xl font-bold text-gray-800">Agenda de Atendimentos</h2>
                </div>
                
                <form method="GET" action="<?php echo e(route('agendamentos.agenda')); ?>" class="flex flex-col sm:flex-row gap-3 sm:gap-4 w-full">
                    <div class="flex-1">
                        <label class="block text-xs sm:text-sm font-medium text-gray-700 mb-1">Data</label>
                        <input type="date" name="data" value="<?php echo e($data); ?>" 
                               class="block w-full rounded-md border-gray-300 shadow-sm focus:border-vm-gold focus:ring-vm-gold text-sm">
                    </div>
                    
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isProprietaria')): ?>
                        <div class="flex-1">
                            <label class="block text-xs sm:text-sm font-medium text-gray-700 mb-1">Profissional</label>
                            <select name="profissional_id" class="block w-full rounded-md border-gray-300 shadow-sm focus:border-vm-gold focus:ring-vm-gold text-sm">
                                <option value="">Todos</option>
                                <?php $__currentLoopData = $profissionais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prof): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($prof->id); ?>" <?php echo e($profissionalId == $prof->id ? 'selected' : ''); ?>>
                                        <?php echo e($prof->nome); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    <?php endif; ?>
                    
                    <button type="submit" class="btn-secondary w-full sm:w-auto sm:mt-6">
                        Filtrar
                    </button>
                </form>

                <a href="<?php echo e(route('agendamentos.create')); ?>" class="btn-primary w-full sm:w-auto text-center">
                    + Novo Agendamento
                </a>
            </div>
        </div>
    </div>

    <!-- Lista de Agendamentos -->
    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
        <div class="p-3 sm:p-6">
            <div class="space-y-3 sm:space-y-4">
                <?php $__empty_1 = true; $__currentLoopData = $agendamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agendamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="rounded-lg p-3 sm:p-4 hover:shadow-xl transition-all duration-300 border-l-4
                        <?php if($agendamento->status == 'concluido'): ?> 
                            bg-gradient-to-r from-green-500 to-green-600 border-green-700 text-white
                        <?php elseif($agendamento->status == 'pre_concluido'): ?> 
                            bg-gradient-to-r from-orange-400 to-orange-500 border-orange-600 text-white
                        <?php elseif($agendamento->status == 'agendado'): ?> 
                            bg-gradient-to-r from-blue-500 to-blue-600 border-blue-700 text-white
                        <?php else: ?> 
                            bg-gradient-to-r from-gray-400 to-gray-500 border-gray-600 text-white
                        <?php endif; ?>">
                        <div class="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-3">
                            <div class="flex-1">
                                <div class="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3">
                                    <div class="text-2xl sm:text-3xl font-bold text-white drop-shadow-lg">
                                        <?php echo e($agendamento->data_hora->format('H:i')); ?>

                                    </div>
                                    <div class="flex-1">
                                        <div class="font-bold text-white text-base sm:text-lg"><?php echo e($agendamento->nome_cliente); ?></div>
                                        <?php if($agendamento->servico): ?>
                                            <div class="text-sm sm:text-base text-white/90"><?php echo e($agendamento->servico->nome); ?> - R$ <?php echo e(number_format($agendamento->servico->preco, 2, ',', '.')); ?></div>
                                        <?php else: ?>
                                            <div class="text-sm sm:text-base text-white/70">Serviço não especificado</div>
                                        <?php endif; ?>
                                        <div class="text-xs sm:text-sm text-white/80 mt-1">
                                            Profissional: <?php echo e($agendamento->profissional->nome); ?>

                                            <?php if($agendamento->servico && $agendamento->servico->duracao_minutos): ?>
                                                • <?php echo e($agendamento->servico->duracao_minutos); ?>min
                                            <?php endif; ?>
                                        </div>
                                        <?php if($agendamento->observacoes): ?>
                                            <div class="text-xs sm:text-sm text-white/80 mt-1 bg-white/10 rounded px-2 py-1 inline-block">
                                                <strong>Obs:</strong> <?php echo e($agendamento->observacoes); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="flex flex-wrap items-center gap-2">
                                <span class="px-3 py-1 text-xs rounded-full font-bold bg-white/20 backdrop-blur-sm text-white border border-white/30">
                                    <?php if($agendamento->status == 'concluido'): ?> ✓ Confirmado
                                    <?php elseif($agendamento->status == 'pre_concluido'): ?> ⏳ Pré-Concluído
                                    <?php elseif($agendamento->status == 'agendado'): ?> ⏰ Agendado
                                    <?php else: ?> ✕ Cancelado
                                    <?php endif; ?>
                                </span>
                                
                                <?php if($agendamento->status == 'agendado'): ?>
                                    <a href="<?php echo e(route('agendamentos.concluir', $agendamento)); ?>" 
                                       class="px-2 sm:px-3 py-1 bg-white text-green-700 text-xs font-semibold rounded hover:bg-green-50 whitespace-nowrap shadow-md">
                                        ✓ Concluir
                                    </a>
                                    
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isProprietaria')): ?>
                                        <a href="<?php echo e(route('agendamentos.edit', $agendamento)); ?>" 
                                           class="px-2 sm:px-3 py-1 bg-white text-blue-700 text-xs font-semibold rounded hover:bg-blue-50 whitespace-nowrap shadow-md">
                                            ✎ Editar
                                        </a>
                                        
                                        <form method="POST" action="<?php echo e(route('agendamentos.destroy', $agendamento)); ?>" class="inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" onclick="return confirm('Deseja realmente cancelar?')"
                                                    class="px-2 sm:px-3 py-1 bg-white text-red-700 text-xs font-semibold rounded hover:bg-red-50 whitespace-nowrap shadow-md">
                                                ✕
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                <?php endif; ?>
                                
                                <?php if($agendamento->status == 'pre_concluido'): ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isProprietaria')): ?>
                                        <form method="POST" action="<?php echo e(route('agendamentos.confirmar', $agendamento)); ?>" class="inline">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" 
                                                    class="px-2 sm:px-3 py-1 bg-white text-green-700 text-xs font-semibold rounded hover:bg-green-50 whitespace-nowrap shadow-md">
                                                ✓ Confirmar
                                            </button>
                                        </form>
                                        
                                        <form method="POST" action="<?php echo e(route('agendamentos.destroy', $agendamento)); ?>" class="inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" onclick="return confirm('Cancelar e estornar este atendimento?')"
                                                    class="px-2 sm:px-3 py-1 bg-white text-red-700 text-xs font-semibold rounded hover:bg-red-50 whitespace-nowrap shadow-md">
                                                ✕ Cancelar
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                <?php endif; ?>
                                
                                <?php if($agendamento->status == 'concluido'): ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isProprietaria')): ?>
                                        <form method="POST" action="<?php echo e(route('agendamentos.destroy', $agendamento)); ?>" class="inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" onclick="return confirm('ATENÇÃO: Cancelar este agendamento irá REMOVER os pagamentos registrados e ALTERAR os valores financeiros. Deseja realmente continuar?')"
                                                    class="px-2 sm:px-3 py-1 bg-white text-orange-700 text-xs font-semibold rounded hover:bg-orange-50 whitespace-nowrap shadow-md">
                                                <span class="hidden sm:inline">↩ Cancelar e Estornar</span>
                                                <span class="sm:hidden">↩ Estornar</span>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                <?php endif; ?>

                                <?php if($agendamento->status == 'cancelado' || $agendamento->status == 'concluido'): ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isProprietaria')): ?>
                                        <form method="POST" action="<?php echo e(route('agendamentos.deletar', $agendamento)); ?>" class="inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" onclick="return confirm('ATENÇÃO: Esta ação é IRREVERSÍVEL! O agendamento será DELETADO PERMANENTEMENTE do banco de dados. Deseja realmente continuar?')"
                                                    class="px-2 sm:px-3 py-1 bg-white text-red-700 text-xs font-semibold rounded hover:bg-red-50 whitespace-nowrap shadow-md">
                                                🗑️ <span class="hidden sm:inline">Deletar</span>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="text-center py-12">
                        <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                        </svg>
                        <h3 class="mt-2 text-sm font-medium text-gray-900">Nenhum agendamento</h3>
                        <p class="mt-1 text-sm text-gray-500">Não há agendamentos para esta data.</p>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isProprietaria')): ?>
                            <div class="mt-6">
                                <a href="<?php echo e(route('agendamentos.create')); ?>" class="inline-flex items-center px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">
                                    + Novo Agendamento
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alexandre\Desktop\sistema para esmalteria\resources\views/agendamentos/agenda.blade.php ENDPATH**/ ?>