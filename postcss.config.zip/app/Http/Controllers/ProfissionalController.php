<?php

namespace App\Http\Controllers;

use App\Models\Profissional;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class ProfissionalController extends Controller
{
    public function index()
    {
        $profissionais = Profissional::with('user')->get();
        return view('profissionais.index', compact('profissionais'));
    }

    public function create()
    {
        return view('profissionais.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'nome' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'telefone' => 'nullable|string|max:20',
            'password' => 'required|string|min:8',
            'percentual_comissao' => 'required|numeric|min:0|max:100',
            'avatar' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        // Upload avatar
        $avatarPath = null;
        if ($request->hasFile('avatar')) {
            $avatarPath = $request->file('avatar')->store('avatars', 'public');
        }

        // Criar usuário
        $user = User::create([
            'name' => $request->nome,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'tipo' => 'profissional',
            'avatar' => $avatarPath,
        ]);

        // Criar profissional
        Profissional::create([
            'user_id' => $user->id,
            'nome' => $request->nome,
            'telefone' => $request->telefone,
            'avatar' => $avatarPath,
            'percentual_comissao' => $request->percentual_comissao,
        ]);

        return redirect()->route('profissionais.index')
            ->with('success', 'Profissional cadastrado com sucesso!');
    }

    public function edit(Profissional $profissional)
    {
        return view('profissionais.edit', compact('profissional'));
    }

    public function update(Request $request, Profissional $profissional)
    {
        $request->validate([
            'nome' => 'required|string|max:255',
            'telefone' => 'nullable|string|max:20',
            'percentual_comissao' => 'required|numeric|min:0|max:100',
            'avatar' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        $dados = [
            'nome' => $request->nome,
            'telefone' => $request->telefone,
            'percentual_comissao' => $request->percentual_comissao,
        ];

        // Upload novo avatar se fornecido
        if ($request->hasFile('avatar')) {
            // Deletar avatar antigo se existir
            if ($profissional->avatar && \Storage::disk('public')->exists($profissional->avatar)) {
                \Storage::disk('public')->delete($profissional->avatar);
            }
            
            $dados['avatar'] = $request->file('avatar')->store('avatars', 'public');
        }

        $profissional->update($dados);

        // Atualizar user também
        $dadosUser = ['name' => $request->nome];
        if (isset($dados['avatar'])) {
            $dadosUser['avatar'] = $dados['avatar'];
        }
        $profissional->user->update($dadosUser);

        return redirect()->route('profissionais.index')
            ->with('success', 'Profissional atualizado com sucesso!');
    }

    public function destroy(Profissional $profissional)
    {
        $profissional->user->delete();
        return redirect()->route('profissionais.index')
            ->with('success', 'Profissional removido com sucesso!');
    }

    public function toggleStatus(Profissional $profissional)
    {
        $profissional->update(['ativo' => !$profissional->ativo]);
        
        return redirect()->route('profissionais.index')
            ->with('success', 'Status atualizado com sucesso!');
    }
}

